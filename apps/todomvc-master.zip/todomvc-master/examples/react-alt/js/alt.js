/*jshint quotmark:false */
/*jshint newcap:false */
/*global Alt */

var app = app || {};

(function () {
	'use strict';

	app.alt = new Alt();
})();
