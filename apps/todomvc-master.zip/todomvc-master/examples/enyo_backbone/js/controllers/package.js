/*global enyo:false */
enyo.depends(
	'NotepadController.js',
	'Routes.js'
);
